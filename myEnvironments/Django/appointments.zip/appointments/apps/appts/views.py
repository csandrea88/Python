from django.shortcuts import render, redirect
from .models import *
from django.contrib import messages
import bcrypt
import datetime 
from datetime import date

now = datetime.datetime.now()


def index(request):
    return render(request,'appts/index.html')

def register(request):

    reg_errors = Users.objects.register_validator(request.POST)
    # print "Are there any errors: {}".format(reg_errors)
    # print "TYPE OF THING IS {}".format(type(reg_errors))
    if type(reg_errors) == list:
        for error in reg_errors:
            messages.error(request,error)
        return redirect ("/")
    else:
        request.session['userid'] = reg_errors.id 
        request.session['first_name'] = reg_errors.first_name

        return redirect ("/appts")

def login(request):  
    print request.POST

    login_errors = Users.objects.login_validator(request.POST)

    if len(login_errors) > 0:
        for error in login_errors:
           messages.error(request,error)
        return redirect("/")

    login = Users.objects.filter(email = request.POST['email'])

    if len(login) == 0:
        login_errors.append("Login: Email does not exist, invalid login")
        for error in login_errors:
            messages.error(request,error)
        return redirect("/") 

    elif len(login) == 1:
        User_Password = login[0].Password

        User_id = login[0].id
        first_name = login[0].first_name

        print User_id, User_Password, request.POST['password']
        if bcrypt.checkpw(request.POST['password'].encode(), User_Password.encode()) == True:
            request.session['userid'] = User_id
            print request.session['userid']
            request.session['first_name'] = first_name
            print "TRYINNG TO REDIRECT!!!!!"
            return redirect("/appts")

        else:
            login_errors.append("Login: Invalid Password")
            if login_errors > 0:
                for error in login_errors:
                    messages.error(request,error)
                return redirect("/")     

def logout(request):
    del request.session['userid'] 
    del request.session['first_name'] 
    return redirect ("/") 

# appt Routes
def appts(request):
    print "i am  in appt"
    print "print date: {}".format(date.today())
    context = {
        "appts": Appts.objects.all()
        #"appts": Appts.objects.filter(date == date.today())
        #"userappts": Appts.objects.filter(user=Appts.objects.get(id=request.session['userid']))
    }
    return render(request,'appts/appts.html', context)

# def destroy(request, id):
#     print "in destroy"
#     #perform delete
#     return redirect("/appts")

def add(request):
    
    add_errors = Appts.objects.Appts_validator(request.POST)
    
    if len(add_errors) == 0: 
        newappt = Appts.objects.create(
            tasks=request.POST['addtask'], 
            date=request.POST['adddate'],
            time=request.POST['addtime'],
            status = "Pending",
            user = Users.objects.get(id=request.session['userid'])
        )
    print "in add and checking errors"
    if type(add_errors) == list:
        for error in add_errors:
            messages.error(request,error)
    print "about to redirect to appt"   
    return redirect("/appts")

# def like(request, id):
    
#     print "in like"
#     user = Users.objects.get(id=request.session['userid'])
#     print user
#     course = Courses.objects.get(id=id)
#     print course
#     print now
#     course.Likes.add(user)
#     course.save()

#     return redirect("/course")

# def edit(request):
#     print "in edit"
#     return redirect("/appts")

