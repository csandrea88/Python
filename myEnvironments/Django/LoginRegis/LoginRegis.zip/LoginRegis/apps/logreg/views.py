from django.shortcuts import render, redirect
from .models import Users
from django.contrib import messages
import bcrypt

def index(request):
    return render(request,'logreg/index.html')

def success(request):
    return render(request,'logreg/success.html')


def register(request):

    reg_errors = Users.objects.register_validator(request.POST)
    print "Are there any errors: {}".format(reg_errors)
    if len(reg_errors) > 0:
        for error in reg_errors:
            messages.error(request,error)
        return redirect ("/")

    else:
        return redirect ("/success")

def login(request):
    print "in login routine before checking errors"
    login_errors = Users.objects.login_validator(request.POST)

    if len(login_errors) > 0:
        print "login_errors: {}".format(login_errors)
        for error in login_errors:
           messages.error(request,error)
        return redirect ("/")

    print "i am before Users filter to check for email"
    login = Users.objects.filter(email = request.POST['email'])
    
    print "login: Users table search by email results: {}".format(login)

    if len(login) == 0:
        print "In len(login) == 0"
        login_errors.append("Login: Email does not exist, invalid login")
        if login_errors > 0:
            for error in login_errors:
                messages.error(request,error)
        return redirect ("/") 

    elif len(login) == 1:
        User_Password = login[0].Password
        print "In len(login) == 1"
        #login_passhash1 = bcrypt.hashpw("request.POST['password']".encode(), bcrypt.gensalt())
        print User_Password
        print request.POST['password']
        print "checkpw resulsts: {}".format(bcrypt.checkpw(request.POST['password'].encode(), User_Password.encode()))
        if bcrypt.checkpw(request.POST['password'].encode(), User_Password.encode()) == True:
            print "in password match"
            return redirect ("/success")
        else:
            login_errors.append("Login: Invalid Password")
            if login_errors > 0:
                for error in login_errors:
                    messages.error(request,error)
                return redirect ("/")     

