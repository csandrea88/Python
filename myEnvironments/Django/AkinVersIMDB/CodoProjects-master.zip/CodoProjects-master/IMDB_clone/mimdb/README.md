# mimdb
Collaborative mini-imdb reconstruction project. 
